package com.kotak.google.dialog.flow;


import com.google.cloud.dialogflow.cx.v3.*;
import com.google.common.collect.Lists;
import com.google.api.gax.core.CredentialsProvider;
import com.google.api.gax.core.GoogleCredentialsProvider;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.IOException;

@NoArgsConstructor
@Service
public class GoogleServiceAccessor {
    private static final String GOOGLE_CLOUD_PLATFORM_SCOPE = "https://www.googleapis.com/auth/cloud-platform";
    public static final String GOOGLE_CLOUD_PLATFORM_ASIA_SOUTH1_ENDPOINT = "asia-south1-dialogflow.googleapis.com:443";

    String GOOGLE_CLOUD_PLATFORM_DEFAULT_TIMEZONE = "Asia/Colombo";
    public static final String GOOGLE_CLOUD_PLATFORM_PROJECT_LOCATION = "projects/disco-ceremony-398809/locations/asia-south1";

    public AgentsClient getAgentClient(){

        com.google.api.gax.core.CredentialsProvider credentialsProvider = getCredentialsProvider();

        AgentsClient agentsClient = null;

        try{
            agentsClient = AgentsClient
                    .create(AgentsSettings.newBuilder()
                            .setCredentialsProvider(credentialsProvider)
                            .setEndpoint(GOOGLE_CLOUD_PLATFORM_ASIA_SOUTH1_ENDPOINT)
                            .build());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return agentsClient;
    }

    public com.google.api.gax.core.CredentialsProvider getCredentialsProvider(){
        return GoogleCredentialsProvider.newBuilder()
                .setScopesToApply(Lists.newArrayList(GOOGLE_CLOUD_PLATFORM_SCOPE))
                .build();
    }

    public IntentsClient getIntentsClient(){

        CredentialsProvider credentialsProvider = getCredentialsProvider();

        IntentsClient intentsClient = null;
        try {
            intentsClient = IntentsClient
                    .create(IntentsSettings.newBuilder()
                            .setEndpoint(GOOGLE_CLOUD_PLATFORM_ASIA_SOUTH1_ENDPOINT)
                            .setCredentialsProvider(credentialsProvider)
                            .build());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return intentsClient;
    }

    public FlowsClient getFlowsClient(){

        CredentialsProvider credentialsProvider = getCredentialsProvider();

        FlowsClient flowsClient = null;
        try {
            flowsClient = FlowsClient
                    .create(FlowsSettings.newBuilder()
                            .setEndpoint(GOOGLE_CLOUD_PLATFORM_ASIA_SOUTH1_ENDPOINT)
                            .setCredentialsProvider(credentialsProvider)
                            .build());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return flowsClient;
    }

    public EntityTypesClient getEntityTypesClient(){
        CredentialsProvider credentialsProvider = getCredentialsProvider();

        EntityTypesClient entityTypesClient = null;
        try {
            entityTypesClient = EntityTypesClient
                    .create(EntityTypesSettings.newBuilder()
                            .setEndpoint(GOOGLE_CLOUD_PLATFORM_ASIA_SOUTH1_ENDPOINT)
                            .setCredentialsProvider(credentialsProvider)
                            .build());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return entityTypesClient;
    }

}


