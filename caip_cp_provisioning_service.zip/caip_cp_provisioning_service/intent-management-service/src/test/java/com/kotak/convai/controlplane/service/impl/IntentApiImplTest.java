package com.kotak.convai.controlplane.service.impl;

import com.google.cloud.dialogflow.cx.v3.CreateIntentRequest;
import com.google.cloud.dialogflow.cx.v3.Intent;
import com.google.cloud.dialogflow.cx.v3.IntentsClient;
import com.google.cloud.dialogflow.cx.v3.UpdateIntentRequest;
import com.kotak.TenantManagementService;
import com.kotak.convai.controlplane.api.IntentApi;
import com.kotak.convai.controlplane.model.ConvAIAddIntentRequest;
import com.kotak.convai.controlplane.model.ConvAIIntent;
import com.kotak.convai.controlplane.model.ConvAIIntentResponseGetAll;
import com.kotak.convai.controlplane.model.ConvAIUpdateIntentRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;

import static com.kotak.convai.controlplane.service.impl.Helper.*;
import static com.kotak.convai.controlplane.service.impl.SubHelper.ParameterToConvAIParameter;
import static com.kotak.convai.controlplane.service.impl.SubHelper.TrainingPhrasesToConvAITrainingPhrases;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@SpringBootTest(classes = com.kotak.convai.controlplane.service.impl.IntentApiImpl.class)
@ExtendWith(MockitoExtension.class)
public class IntentApiImplTest {

    private IntentApi intentApi;
    @MockBean
    private TenantManagementService tenantManagementService;
    @MockBean
    private IntentsClient intentsClient;
    @MockBean
    private IntentsClient.ListIntentsPagedResponse listIntentsPagedResponse;


    private static final String TEST_TENANT_ID = "test-tenant";
    private static final String TEST_TENANT_AGENT_ID = "projects/test-project/locations/south-asia1/agents/test-agent";
    private static final String TEST_INTENT_DISPLAY_NAME = "TestIntent";
    private static final String TEST_INTENT_UPDATED_DISPLAY_NAME = "UpdatedTestIntent";
    private static final String TEST_INTENT_NAME = TEST_TENANT_AGENT_ID+ "/intents/"+ TEST_INTENT_DISPLAY_NAME;
    private static final String TEST_INTENT_DESCRIPTION = "Test description";
    private static final String TEST_INTENT_UPDATED_DESCRIPTION = "Updated Test description";
    private static final int TEST_INTENT_PRIORITY = 500000;
    private static final int TEST_INTENT_UPDATED_PRIORITY = 500001;
    private static final int TEST_INTENT_NUM_TRAINING_PHRASES = 2;
    private static final String TEST_INTENT_TRAINING_PHRASES_PARTS_TEXT1 = "Hello, how are you?";
    private static final String TEST_INTENT_TRAINING_PHRASES_PARTS_TEXT2 = "How can I help you?";
    private static final int TEST_INTENT_TRAINING_PHRASES_REPEAT_COUNT= 1;
    private static final String TEST_INTENT_TRAINING_PHRASES_PARAMETER_ID = "";
    private static final String TEST_INTENT_ENTITY_TYPE = "color2";
    private static final String INTENT_NAME_IN_PATH_DOES_NOT_MATCH_IN_BODY_UPDATE_INTENT_EXCEPTION_MESSAGE = "Provided intent name in path does not match intent name in request body for updating intent";
    private static final String INTENT_NAME_PROVIDED_IN_BODY_ADD_INTENT_EXCEPTION_MESSAGE = "Intent name should not be provided in request body for creating an intent.";
    private static final String TENANT_ID_PROVIDED_NOT_FOUND_EXCEPTION = "Provided Tenant ID was not found.";
    private static final String INTENT_DISPLAY_NAME_CAN_NOT_BE_EMPTY = "Intent Display name can't be empty.";
    private static final List<Intent.TrainingPhrase> TrainingPhrasesList = Arrays.asList(
            Intent.TrainingPhrase.newBuilder().addParts(Intent.TrainingPhrase.Part.newBuilder().setText(TEST_INTENT_TRAINING_PHRASES_PARTS_TEXT1).build()).setRepeatCount(TEST_INTENT_TRAINING_PHRASES_REPEAT_COUNT).build(),
            Intent.TrainingPhrase.newBuilder().addParts(Intent.TrainingPhrase.Part.newBuilder().setText(TEST_INTENT_TRAINING_PHRASES_PARTS_TEXT2).build()).setRepeatCount(TEST_INTENT_TRAINING_PHRASES_REPEAT_COUNT).build());
    private static final List<Intent.Parameter> ParametersList = Arrays.asList(
            Intent.Parameter.newBuilder().setId(TEST_INTENT_TRAINING_PHRASES_PARAMETER_ID).setEntityType(TEST_INTENT_ENTITY_TYPE).setIsList(false).setRedact(false).build());


    @BeforeEach
    public void setup(){
        intentApi = new IntentApiImpl(tenantManagementService,intentsClient);
        when(tenantManagementService.getAgentIdByTenantId(TEST_TENANT_ID)).thenReturn(Optional.ofNullable(TEST_TENANT_AGENT_ID));

    }


//ADD_INTENT TEST CASES:
    @Test
    public void addIntent_happyCase(){
        ConvAIAddIntentRequest requestObject = buildConvAIAddIntentRequest(null,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,TrainingPhrasesToConvAITrainingPhrases(TrainingPhrasesList),ParameterToConvAIParameter(ParametersList));
        ConvAIIntent expectedResponse = Helper.buildConvAIIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,TrainingPhrasesToConvAITrainingPhrases(TrainingPhrasesList),ParameterToConvAIParameter(ParametersList));
        Intent mockIntent = Helper.buildIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,TrainingPhrasesList,ParametersList);
        CreateIntentRequest mockIntentRequest = CreateIntentRequest.newBuilder()
                .setParent(TEST_TENANT_AGENT_ID)
                .setIntent(Helper.convAIIntentToIntent(requestObject))
                .build();
        when(intentsClient.createIntent(mockIntentRequest)).thenReturn(mockIntent);
        ResponseEntity<ConvAIIntent> responseObject = intentApi.addIntent(TEST_TENANT_ID,requestObject);
        assertEquals(ResponseEntity.ok(expectedResponse),responseObject);
    }

    @Test
    public void addIntent_InputsNotSentInRequest(){
        ConvAIAddIntentRequest requestObject = buildConvAIAddIntentRequest(null,TEST_INTENT_DISPLAY_NAME,-1,null,null,null);
        ConvAIIntent expectedResponse = Helper.buildConvAIIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,-1,null,null,null);
        Intent mockIntent = Helper.buildIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,-1,null,null,null);
        CreateIntentRequest mockIntentRequest = CreateIntentRequest.newBuilder()
                .setParent(TEST_TENANT_AGENT_ID)
                .setIntent(Helper.convAIIntentToIntent(requestObject))
                .build();
        when(intentsClient.createIntent(mockIntentRequest)).thenReturn(mockIntent);
        ResponseEntity<ConvAIIntent> responseObject = intentApi.addIntent(TEST_TENANT_ID,requestObject);
        assertEquals(ResponseEntity.ok(expectedResponse),responseObject);
    }

    @Test
    public void addIntent_InputsNotSentInTrainingPhrasesAndParameters(){
        ConvAIAddIntentRequest requestObject = buildConvAIAddIntentRequest(null,TEST_INTENT_DISPLAY_NAME,-1,null,TrainingPhrasesToConvAITrainingPhrases(null),ParameterToConvAIParameter(null));
        ConvAIIntent expectedResponse = Helper.buildConvAIIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,-1,null,TrainingPhrasesToConvAITrainingPhrases(null),ParameterToConvAIParameter(null));
        Intent mockIntent = Helper.buildIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,-1,null,null,null);
        CreateIntentRequest mockIntentRequest = CreateIntentRequest.newBuilder()
                .setParent(TEST_TENANT_AGENT_ID)
                .setIntent(Helper.convAIIntentToIntent(requestObject))
                .build();
        when(intentsClient.createIntent(mockIntentRequest)).thenReturn(mockIntent);
        ResponseEntity<ConvAIIntent> responseObject = intentApi.addIntent(TEST_TENANT_ID,requestObject);
        assertEquals(ResponseEntity.ok(expectedResponse),responseObject);
    }

    @Test
    public void addIntent_NameSentInRequest(){
        ConvAIAddIntentRequest requestObject = buildConvAIAddIntentRequest(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,TrainingPhrasesToConvAITrainingPhrases(TrainingPhrasesList),ParameterToConvAIParameter(ParametersList));
        Throwable exception = assertThrows(ResponseStatusException.class, () -> intentApi.addIntent(TEST_TENANT_ID,requestObject));
        assertTrue(exception.getMessage().contains(INTENT_NAME_PROVIDED_IN_BODY_ADD_INTENT_EXCEPTION_MESSAGE));
    }

    @Test
    public void addIntent_DisplayNameNotSentInRequest(){
        ConvAIAddIntentRequest requestObject = buildConvAIAddIntentRequest(null,null,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,TrainingPhrasesToConvAITrainingPhrases(TrainingPhrasesList),ParameterToConvAIParameter(ParametersList));
        Throwable exception = assertThrows(ResponseStatusException.class, () -> intentApi.addIntent(TEST_TENANT_ID,requestObject));
        assertTrue(exception.getMessage().contains(INTENT_DISPLAY_NAME_CAN_NOT_BE_EMPTY));
    }

    @Test
    public void addIntent_TenantIDNotFound() {
        ConvAIAddIntentRequest requestObject = buildConvAIAddIntentRequest(null, TEST_INTENT_DISPLAY_NAME, TEST_INTENT_PRIORITY, TEST_INTENT_DESCRIPTION, TrainingPhrasesToConvAITrainingPhrases(TrainingPhrasesList), ParameterToConvAIParameter(ParametersList));
        when(tenantManagementService.getAgentIdByTenantId(TEST_TENANT_ID)).thenReturn(Optional.ofNullable(null));
        Throwable exception = assertThrows(NoSuchElementException.class, () -> intentApi.addIntent(TEST_TENANT_ID,requestObject));
        assertTrue(exception.getMessage().contains(TENANT_ID_PROVIDED_NOT_FOUND_EXCEPTION));
    }


    //UPDATE_INTENT TEST CASES:
    @Test
    public void updateIntent_happyCase(){

        ConvAIUpdateIntentRequest requestObject = Helper.buildConvAIUpdateIntentRequest(TEST_INTENT_NAME,TEST_INTENT_UPDATED_DISPLAY_NAME,TEST_INTENT_UPDATED_PRIORITY,TEST_INTENT_UPDATED_DESCRIPTION,TrainingPhrasesToConvAITrainingPhrases(TrainingPhrasesList),ParameterToConvAIParameter(ParametersList));
        ConvAIIntent expectedResponse = Helper.buildConvAIIntent(TEST_INTENT_NAME,TEST_INTENT_UPDATED_DISPLAY_NAME,TEST_INTENT_UPDATED_PRIORITY,TEST_INTENT_UPDATED_DESCRIPTION,TrainingPhrasesToConvAITrainingPhrases(TrainingPhrasesList),ParameterToConvAIParameter(ParametersList));

        Intent mockIntent = Helper.buildIntent(TEST_INTENT_NAME,TEST_INTENT_UPDATED_DISPLAY_NAME,TEST_INTENT_UPDATED_PRIORITY,TEST_INTENT_UPDATED_DESCRIPTION,TrainingPhrasesList,ParametersList);

        UpdateIntentRequest mockIntentRequest = UpdateIntentRequest.newBuilder()
                        .setIntent(convAIIntentToIntent(requestObject))
                        .build();

        when(intentsClient.updateIntent(mockIntentRequest)).thenReturn(mockIntent);

        ResponseEntity<ConvAIIntent> responseObject = intentApi.updateIntent(TEST_TENANT_ID,TEST_INTENT_DISPLAY_NAME,requestObject);
        assertEquals(ResponseEntity.ok(expectedResponse),responseObject);
    }

    @Test
    public void updateIntent_InputsNotSentInRequest(){
        ConvAIUpdateIntentRequest requestObject = Helper.buildConvAIUpdateIntentRequest(TEST_INTENT_NAME,TEST_INTENT_UPDATED_DISPLAY_NAME,-1,null,null,null);
        ConvAIIntent expectedResponse = Helper.buildConvAIIntent(TEST_INTENT_NAME,TEST_INTENT_UPDATED_DISPLAY_NAME,-1,null,null,null);

        Intent mockIntent = Helper.buildIntent(TEST_INTENT_NAME,TEST_INTENT_UPDATED_DISPLAY_NAME,-1,null,null,null);


        UpdateIntentRequest mockIntentRequest = UpdateIntentRequest.newBuilder()
                .setIntent(convAIIntentToIntent(requestObject))
                .build();

        when(intentsClient.updateIntent(mockIntentRequest)).thenReturn(mockIntent);

        ResponseEntity<ConvAIIntent> responseObject = intentApi.updateIntent(TEST_TENANT_ID,TEST_INTENT_DISPLAY_NAME,requestObject);
        assertEquals(ResponseEntity.ok(expectedResponse),responseObject);
    }

    @Test
    public void updateIntent_InputIntentNameAndRequestBodyIntentNameMismatch() {
        ConvAIUpdateIntentRequest requestObject = buildConvAIUpdateIntentRequest(TEST_INTENT_NAME, TEST_INTENT_DISPLAY_NAME, TEST_INTENT_PRIORITY, TEST_INTENT_DESCRIPTION, TrainingPhrasesToConvAITrainingPhrases(TrainingPhrasesList), ParameterToConvAIParameter(ParametersList));
        Throwable exception = assertThrows(ResponseStatusException.class, () -> intentApi.updateIntent(TEST_TENANT_ID, TEST_INTENT_NAME, requestObject));
        assertTrue(exception.getMessage().contains(INTENT_NAME_IN_PATH_DOES_NOT_MATCH_IN_BODY_UPDATE_INTENT_EXCEPTION_MESSAGE));
    }

    @Test
    public void updateIntent_TenantIDNotFound() {
        ConvAIUpdateIntentRequest requestObject = buildConvAIUpdateIntentRequest(TEST_INTENT_NAME, TEST_INTENT_DISPLAY_NAME, TEST_INTENT_PRIORITY, TEST_INTENT_DESCRIPTION, TrainingPhrasesToConvAITrainingPhrases(TrainingPhrasesList), ParameterToConvAIParameter(ParametersList));
        when(tenantManagementService.getAgentIdByTenantId(TEST_TENANT_ID)).thenReturn(Optional.ofNullable(null));
        Throwable exception = assertThrows(NoSuchElementException.class, () -> intentApi.updateIntent(TEST_TENANT_ID,TEST_INTENT_DISPLAY_NAME,requestObject));
        assertTrue(exception.getMessage().contains(TENANT_ID_PROVIDED_NOT_FOUND_EXCEPTION));
    }

    @Test
    public void updateIntent_IntentDisplayNameNotProvided() {
        ConvAIUpdateIntentRequest requestObject = buildConvAIUpdateIntentRequest(TEST_INTENT_NAME, null, TEST_INTENT_PRIORITY, TEST_INTENT_DESCRIPTION, TrainingPhrasesToConvAITrainingPhrases(TrainingPhrasesList), ParameterToConvAIParameter(ParametersList));
        Throwable exception = assertThrows(ResponseStatusException.class, () -> intentApi.updateIntent(TEST_TENANT_ID,TEST_INTENT_DISPLAY_NAME,requestObject));
        assertTrue(exception.getMessage().contains(INTENT_DISPLAY_NAME_CAN_NOT_BE_EMPTY));
    }


//GET_INTENT TEST CASES:
    @Test
    public void getIntent_happyCase(){
        ConvAIIntent expectedResponse = Helper.buildConvAIIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,TrainingPhrasesToConvAITrainingPhrases(TrainingPhrasesList),ParameterToConvAIParameter(ParametersList));
        Intent mockIntent = Helper.buildIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,(TrainingPhrasesList),(ParametersList));
        when(intentsClient.getIntent(TEST_INTENT_NAME)).thenReturn(mockIntent);
        System.out.println(TEST_INTENT_NAME);
        ResponseEntity<ConvAIIntent> responseObject = intentApi.getIntent(TEST_TENANT_ID, TEST_INTENT_DISPLAY_NAME);
        assertEquals(ResponseEntity.ok(expectedResponse), responseObject);
    }

    @Test
    public void getIntent_nullInputs(){
        ConvAIIntent expectedResponse = Helper.buildConvAIIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,-1,null,null,null);
        Intent mockIntent = Helper.buildIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,-1,null,null,null);
        when(intentsClient.getIntent(TEST_INTENT_NAME)).thenReturn(mockIntent);
        System.out.println(TEST_INTENT_NAME);
        ResponseEntity<ConvAIIntent> responseObject = intentApi.getIntent(TEST_TENANT_ID, TEST_INTENT_DISPLAY_NAME);
        assertEquals(ResponseEntity.ok(expectedResponse), responseObject);
    }

    @Test
    public void getIntent_TenantIDNotFound() {
        when(tenantManagementService.getAgentIdByTenantId(TEST_TENANT_ID)).thenReturn(Optional.ofNullable(null));
        Throwable exception = assertThrows(NoSuchElementException.class, () -> intentApi.getIntent(TEST_TENANT_ID,TEST_INTENT_DISPLAY_NAME));
        assertTrue(exception.getMessage().contains(TENANT_ID_PROVIDED_NOT_FOUND_EXCEPTION));
    }

    @Test
    public void getIntent_IntentDisplayNameNotProvided() {
        assertThrows(NullPointerException.class, () -> intentApi.getIntent(TEST_TENANT_ID, null));
    }


//GET_ALL_INTENTS TEST CASES:
    @Test
    public void getAllIntents_happyCase(){
        ConvAIIntentResponseGetAll expectedResponse1 = Helper.buildConvAIIntentResponseGetAll(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,TEST_INTENT_NUM_TRAINING_PHRASES);
        ConvAIIntentResponseGetAll expectedResponse2 = Helper.buildConvAIIntentResponseGetAll(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,TEST_INTENT_NUM_TRAINING_PHRASES);
        ConvAIIntentResponseGetAll expectedResponse3 = Helper.buildConvAIIntentResponseGetAll(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,TEST_INTENT_NUM_TRAINING_PHRASES);

        List<ConvAIIntentResponseGetAll> expectedResponse = new ArrayList<>();
        expectedResponse.add(expectedResponse1);
        expectedResponse.add(expectedResponse2);
        expectedResponse.add(expectedResponse3);

        Intent mockIntent1 = Helper.buildIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,(TrainingPhrasesList),(ParametersList));
        Intent mockIntent2 = Helper.buildIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,(TrainingPhrasesList),(ParametersList));
        Intent mockIntent3 = Helper.buildIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,(TrainingPhrasesList),(ParametersList));

        List<Intent> mockIntent = new ArrayList<>();
        mockIntent.add(mockIntent1);
        mockIntent.add(mockIntent2);
        mockIntent.add(mockIntent3);

        when(listIntentsPagedResponse.iterateAll()).thenReturn(mockIntent);
        when(intentsClient.listIntents(TEST_TENANT_AGENT_ID)).thenReturn(listIntentsPagedResponse);

        ResponseEntity<List<ConvAIIntentResponseGetAll>> responseObject = intentApi.getAllIntents(TEST_TENANT_ID);
        System.out.println(responseObject);
        assertEquals(ResponseEntity.ok(expectedResponse),responseObject);
    }

    @Test
    public void getAllIntents_nullInputs(){
        ConvAIIntentResponseGetAll expectedResponse1 = Helper.buildConvAIIntentResponseGetAll(TEST_INTENT_NAME,null,-1,null,-1);
        ConvAIIntentResponseGetAll expectedResponse2 = Helper.buildConvAIIntentResponseGetAll(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,-1,null,-1);
        ConvAIIntentResponseGetAll expectedResponse3 = Helper.buildConvAIIntentResponseGetAll(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,-1,null,-1);

        List<ConvAIIntentResponseGetAll> expectedResponse = new ArrayList<>();
        expectedResponse.add(expectedResponse1);
        expectedResponse.add(expectedResponse2);
        expectedResponse.add(expectedResponse3);

        Intent mockIntent1 = Helper.buildIntent(TEST_INTENT_NAME,null,-1,null,null,null);
        Intent mockIntent2 = Helper.buildIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,-1,null,null,null);
        Intent mockIntent3 = Helper.buildIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,-1,null,null,null);

        List<Intent> mockIntent = new ArrayList<>();
        mockIntent.add(mockIntent1);
        mockIntent.add(mockIntent2);
        mockIntent.add(mockIntent3);

        when(listIntentsPagedResponse.iterateAll()).thenReturn(mockIntent);
        when(intentsClient.listIntents(TEST_TENANT_AGENT_ID)).thenReturn(listIntentsPagedResponse);

        ResponseEntity<List<ConvAIIntentResponseGetAll>> responseObject = intentApi.getAllIntents(TEST_TENANT_ID);
        System.out.println(responseObject);
        assertEquals(ResponseEntity.ok(expectedResponse),responseObject);
    }

    @Test
    public void getALLIntent_TenantIDNotFound() {
        when(tenantManagementService.getAgentIdByTenantId(TEST_TENANT_ID)).thenReturn(Optional.ofNullable(null));
        Throwable exception = assertThrows(NoSuchElementException.class, () -> intentApi.getAllIntents(TEST_TENANT_ID));
        assertTrue(exception.getMessage().contains(TENANT_ID_PROVIDED_NOT_FOUND_EXCEPTION));
    }


//DELETE_INTENT TEST CASES:
    @Test
    public void deleteIntent_happyCase(){
        assertEquals(ResponseEntity.ok().build(), intentApi.deleteIntent(TEST_INTENT_NAME,TEST_TENANT_ID));
    }

    @Test
    public void deleteIntent_TenantIDNotFound(){
        when(tenantManagementService.getAgentIdByTenantId(TEST_TENANT_ID)).thenReturn(Optional.ofNullable(null));
        Throwable exception = assertThrows(NoSuchElementException.class, () -> intentApi.deleteIntent(TEST_INTENT_NAME,TEST_TENANT_ID));
        assertTrue(exception.getMessage().contains(TENANT_ID_PROVIDED_NOT_FOUND_EXCEPTION));
    }

}
