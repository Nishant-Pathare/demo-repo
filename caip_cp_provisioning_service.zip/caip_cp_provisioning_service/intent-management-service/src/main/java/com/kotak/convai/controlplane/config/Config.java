package com.kotak.convai.controlplane.config;

import com.google.cloud.dialogflow.cx.v3.IntentsClient;
import com.kotak.TenantManagementService;
import com.kotak.google.dialog.flow.GoogleServiceAccessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Config {
    @Bean
    public TenantManagementService tenantManagementService(){
        return new TenantManagementService();
    }

    @Bean
    public IntentsClient intentsClient(){
        GoogleServiceAccessor googleServiceAccessor = new GoogleServiceAccessor();
        return googleServiceAccessor.getIntentsClient();
    }
}
