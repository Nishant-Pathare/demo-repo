package com.kotak;

import com.google.common.collect.ImmutableMap;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Optional;


public class TenantManagementService {
    public TenantManagementService(){}

    private static final Map<String,String> TENANT_ID_TO_AGENT_ID_TO_MAP = ImmutableMap.of("abc","projects/disco-ceremony-398809/locations/asia-south1/agents/4d70ca90-e84c-4e7b-9076-3bb4f3c1fe39");
    public Optional<String> getAgentIdByTenantId(String tenantId){
        return Optional.ofNullable(TENANT_ID_TO_AGENT_ID_TO_MAP.get(tenantId));
    }

}
