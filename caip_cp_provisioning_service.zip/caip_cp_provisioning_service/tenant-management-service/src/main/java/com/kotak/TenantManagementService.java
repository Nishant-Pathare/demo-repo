package com.kotak;

import com.google.common.collect.ImmutableMap;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Optional;


public class TenantManagementService {
    public TenantManagementService(){}

    private static final Map<String,String> TENANT_ID_TO_AGENT_ID_TO_MAP = ImmutableMap.of("abc","projects/disco-ceremony-398809/locations/asia-south1/agents/4f61e320-1a39-4fd9-8cb6-70abf9e93c1c");
    public Optional<String> getAgentIdByTenantId(String tenantId){
        return Optional.ofNullable(TENANT_ID_TO_AGENT_ID_TO_MAP.get(tenantId));
    }

}
