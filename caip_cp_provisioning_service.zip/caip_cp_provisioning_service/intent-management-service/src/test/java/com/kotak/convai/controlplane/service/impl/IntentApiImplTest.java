package com.kotak.convai.controlplane.service.impl;

import com.google.api.client.util.Lists;
import com.google.api.gax.rpc.ApiException;
import com.google.cloud.dialogflow.cx.v3.*;
import com.kotak.TenantManagementService;
import com.kotak.convai.controlplane.api.IntentApi;
import com.kotak.convai.controlplane.model.*;
import com.kotak.google.dialog.flow.GoogleServiceAccessor;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.checkerframework.checker.units.qual.A;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

import static com.kotak.convai.controlplane.service.impl.Helper.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@SpringBootTest(classes = com.kotak.convai.controlplane.service.impl.IntentApiImpl.class)
@ExtendWith(MockitoExtension.class)
public class IntentApiImplTest {

    private IntentApi intentApi;
    @MockBean
    private TenantManagementService tenantManagementService;
    @MockBean
    private IntentsClient intentsClient;
    @MockBean
    private IntentsClient.ListIntentsPagedResponse listIntentsPagedResponse;

    private static final String TEST_TENANT_ID = "test-tenant";
    private static final String TEST_PROJECT_ID = "disco-ceremony-398809";
    private static final String TEST_LOCATION_ID =  "asia-south1";
    private static final String TEST_TENANT_AGENT_ID = "4d70ca90-e84c-4e7b-9076-3bb4f3c1fe39";
    private static final String TEST_TENANT_AGENT_NAME = "projects/"+TEST_PROJECT_ID+"/locations/"+TEST_LOCATION_ID+"/agents/"+TEST_TENANT_AGENT_ID;
    private static final String TEST_INTENT_DISPLAY_NAME = "TestIntent";
    private static final String TEST_INTENT_UPDATED_DISPLAY_NAME = "UpdatedTestIntent";
    private static final String TEST_INTENT_NAME = TEST_TENANT_AGENT_NAME+ "/intents/"+ TEST_INTENT_DISPLAY_NAME;
    private static final String TEST_INTENT_DESCRIPTION = "Test description";
    private static final String TEST_INTENT_UPDATED_DESCRIPTION = "Updated Test description";
    private static final int TEST_INTENT_PRIORITY = 500000;
    private static final int TEST_INTENT_UPDATED_PRIORITY = 500001;
    private static final int TEST_INTENT_NUM_TRAINING_PHRASES = 1;
    private static final String TEST_INTENT_TRAINING_PHRASES_PARTS_TEXT1 = "Hello, how are you?";
    private static final String TEST_INTENT_TRAINING_PHRASES_PARTS_TEXT2 = "How can I help you?";
    private static final int TEST_INTENT_TRAINING_PHRASES_REPEAT_COUNT= 1;
    private static final String TEST_INTENT_TRAINING_PHRASES_PARAMETER_ID = "";
//
//    public Intent getIntentByDisplayName(String displayName) {
//        String projectId = "disco-ceremony-398809";
//        String location = "asia-south1";
//        String agentId = "4d70ca90-e84c-4e7b-9076-3bb4f3c1fe39";
//        String parent = AgentName.of(projectId, location, agentId).toString();
//
//        Intent intent = null;
//
//        try {
//
//            ListIntentsRequest listRequest = ListIntentsRequest.newBuilder().setParent(parent).build();
//            for (Intent result : intentsClient.listIntents(listRequest).iterateAll()) {
//                if (displayName.equals(result.getDisplayName())) {
//                    intent = result;
//                    break;
//                }
//            }
//        } catch (ApiException e) {
//            throw new RuntimeException("Error communicating with DialogflowCX API", e);
//        }
//
//        return intent;
//    }




    @BeforeEach
    public void setup(){
        System.out.println("hello before each");
        intentApi = new IntentApiImpl(tenantManagementService,intentsClient);
        when(tenantManagementService.getAgentIdByTenantId(TEST_TENANT_ID)).thenReturn(Optional.ofNullable(TEST_TENANT_AGENT_NAME));



    }

    @Test
    public void addIntent_happyCase() {

    }
//
//    @BeforeEach
//    public void init(){
//        MockitoAnnotations.openMocks(this);
//
///*
//        Intent intent = intentsClient.createIntent(CreateIntentRequest.newBuilder()
//                .setParent(TEST_TENANT_AGENT_ID)
//                .setIntent(Intent.newBuilder()
//                .setDisplayName(TEST_INTENT_DISPLAY_NAME)
//                .setDescription(TEST_INTENT_DESCRIPTION)
//                .setPriority(TEST_INTENT_PRIORITY)
//                .addAllTrainingPhrases(Arrays.asList(
//                        Intent.TrainingPhrase.newBuilder().addParts(Intent.TrainingPhrase.Part.newBuilder().setText(TEST_INTENT_TRAINING_PHRASES_PARTS_TEXT1).build()).setRepeatCount(TEST_INTENT_TRAINING_PHRASES_REPEAT_COUNT).build(),
//                        Intent.TrainingPhrase.newBuilder().addParts(Intent.TrainingPhrase.Part.newBuilder().setText(TEST_INTENT_TRAINING_PHRASES_PARTS_TEXT2).build()).setRepeatCount(TEST_INTENT_TRAINING_PHRASES_REPEAT_COUNT).build()
//                )).build()).build());
//
//        CreateIntentRequest mockIntent = CreateIntentRequest.newBuilder()
//                .setIntent(intent).build();
//        when(intentsClient.createIntent(mockIntent)).thenReturn(intent);*/
//    }


    public Iterable<? extends Intent.TrainingPhrase> getIntentTrainingPhrases(List<ConvAITrainingPhrases> intentTrainingPhrases){
        return intentTrainingPhrases != null? intentTrainingPhrases.stream().map(s -> Intent.TrainingPhrase.newBuilder()
                        .setRepeatCount(s.getRepeatCount() !=0? s.getRepeatCount():1)
                        .addAllParts(!s.getParts().isEmpty() ? getParts(s.getParts()) : Lists.newArrayList())
                        .build())
                .collect(Collectors.toList()) : Lists.newArrayList();
    }
    public Iterable<? extends Intent.TrainingPhrase.Part> getParts(List<ConvAIParts> parts){
        return parts != null? parts
                .stream().map(s -> Intent.TrainingPhrase.Part.newBuilder()
                        .setText(s.getText())
                        .setParameterId(s.getParameterId() != null ? s.getParameterId(): "")
                        .build()).collect(Collectors.toList()) : Lists.newArrayList();
    }




    @Test
    public void addIntent_HappyCase() throws IOException {
        ConvAIAddIntentRequest requestObject = buildConvAIAddIntentRequest(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,ConvAITrainingPhrasesList);
        Intent.Builder builder = Intent.newBuilder()

            //***YEH NIKALNE PE ERROR AATAY. INSTEAD INTENT KA NAAM SET HONA CHAHIYE***

               // .setName(requestObject.getIntentName())
                .setPriority(requestObject.getIntentPriority())
                .setDisplayName(requestObject.getIntentDisplayName())
                .setDescription(requestObject.getIntentDescription())
                .addAllTrainingPhrases(getIntentTrainingPhrases(requestObject.getIntentTrainingPhrases()));

        Intent mockedIntent = builder.build();

        String agentName = tenantManagementService.getAgentIdByTenantId(TEST_TENANT_ID).get();
        CreateIntentRequest createIntentRequest = CreateIntentRequest.newBuilder().setIntent(mockedIntent).setParent(agentName).build();
        when(intentsClient.createIntent(createIntentRequest)).thenReturn(mockedIntent);
        ResponseEntity<ConvAIIntentResponse> response = intentApi.addIntent(TEST_TENANT_ID,requestObject);
        System.out.println("Final Response"  + response  + "Mocked intent " + mockedIntent);

        assertEquals(TEST_INTENT_DISPLAY_NAME, Objects.requireNonNull(response.getBody()).getIntentDisplayName());
        assertEquals(TEST_INTENT_DESCRIPTION,response.getBody().getIntentDescription());
        assertEquals(TEST_INTENT_PRIORITY, response.getBody().getIntentPriority());
}

    @Test
    public void deleteIntent_happyCase(){
        Intent mockIntent = Helper.buildIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,TrainingPhrasesList);
        assertEquals(ResponseEntity.ok().build(), intentApi.deleteIntent(TEST_INTENT_NAME,TEST_TENANT_ID));
    }



    @Test
    public void addIntent_happyCase2(){
        ConvAIAddIntentRequest requestObject = Helper.buildConvAIAddIntentRequest(null,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,null);
        ConvAIIntentResponse expectedResponse = Helper.buildConvAIIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,null);
        Intent mockIntent = Helper.buildIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,null);
        CreateIntentRequest mockIntentRequest = CreateIntentRequest.newBuilder()
                .setParent(TEST_TENANT_AGENT_NAME)
                .setIntent(Helper.convAIIntentToIntent(requestObject))
                .build();
        when(intentsClient.createIntent(mockIntentRequest)).thenReturn(mockIntent);
        ResponseEntity<ConvAIIntentResponse> responseObject = intentApi.addIntent(TEST_TENANT_ID,requestObject);
        assertEquals(ResponseEntity.ok(expectedResponse),responseObject);
    }

    @Test
    public void updateIntent_happyCase(){
        ConvAIUpdateIntentRequest requestObject = Helper.buildConvAIUpdateIntentRequest(null,TEST_INTENT_UPDATED_DISPLAY_NAME,TEST_INTENT_UPDATED_PRIORITY,TEST_INTENT_UPDATED_DESCRIPTION,null);
        ConvAIIntentResponse expectedResponse = Helper.buildConvAIIntent(TEST_INTENT_NAME,TEST_INTENT_UPDATED_DISPLAY_NAME,TEST_INTENT_UPDATED_PRIORITY,TEST_INTENT_UPDATED_DESCRIPTION,null);

        Intent mockIntent = Helper.buildIntent(TEST_INTENT_NAME,TEST_INTENT_UPDATED_DISPLAY_NAME,TEST_INTENT_UPDATED_PRIORITY,TEST_INTENT_UPDATED_DESCRIPTION,null);

        Intent mockOriginalIntent = Helper.buildIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,null);

        UpdateIntentRequest mockIntentRequest = UpdateIntentRequest.newBuilder()
                .setIntent(Helper.convAIIntentToIntent(requestObject))
                .build();
        //when(intentsClient.getIntent(mockIntentRequest)).thenReturn(mockIntent)

        when(intentsClient.getIntent(TEST_INTENT_NAME)).thenReturn(mockOriginalIntent);
        when(intentsClient.updateIntent(UpdateIntentRequest.newBuilder()
                .setIntent(mockIntent).build())).thenReturn(mockIntent);

//GET YOGENDER's HELP. AS WE ARE MOCKING, THE INTENT NAME COMES OUT AS NULL. BUT UPDATE AND ALL OTHER FUNCTIONS REQUIRE INTENTNAME

        ResponseEntity<ConvAIIntentResponse> responseObject = intentApi.updateIntent(TEST_TENANT_ID,TEST_INTENT_DISPLAY_NAME,requestObject);
        System.out.println("Final Response"  +responseObject  + "Mocked intent " + mockIntent);
        assertEquals(ResponseEntity.ok(expectedResponse),responseObject);
    }

//    @Test
//    public void getIntent_happyCase(){
//        ConvAIAddIntentRequest requestObject = buildConvAIAddIntentRequest(TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,TEST_INTENT_NUM_TRAINING_PHRASES);
//        Intent.Builder builder = Intent.newBuilder()
//                .setPriority(requestObject.getIntentPriority())
//                .setDisplayName(requestObject.getIntentDisplayName())
//                .setDescription(requestObject.getIntentDescription())
//                .addAllTrainingPhrases(getIntentTrainingPhrases(requestObject.getIntentTrainingPhrases()));
//
//        Intent mockedIntent = builder.build();
//
//        String agentName = tenantManagementService.getAgentIdByTenantId(TEST_TENANT_ID).get();
//        GetIntentRequest getIntentRequest = GetIntentRequest.newBuilder().getName();
//        when(intentsClient.getIntent(getIntentRequest)).thenReturn(mockedIntent);
//        ResponseEntity<ConvAIIntentResponse> response = intentApi.addIntent(TEST_TENANT_ID,requestObject);
////        ConvAIIntentRequest requestObject = buildConvAIIntentRequest(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,TEST_INTENT_NUM_TRAINING_PHRASES);
//        ResponseEntity<ConvAIIntentResponse> responseObject= intentApi.getIntent();
//
//        assertEquals(TEST_INTENT_DESCRIPTION,Objects.requireNonNull(responseObject.getBody()).getIntentDescription());
//        assertEquals(TEST_INTENT_DISPLAY_NAME,responseObject.getBody().getIntentDisplayName());
//        // assertEquals(responseObject.getBody().getIntentNumTrainingPhrases(),TEST_INTENT_NUM_TRAINING_PHRASES);
//        assertEquals(TEST_INTENT_PRIORITY,Objects.requireNonNull(responseObject.getBody()).getPriority());
//   }


    @Test
    public void getAllIntents_happyCase(){
        ConvAIIntentResponse expectedResponse1 = Helper.buildConvAIIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,null);
        ConvAIIntentResponse expectedResponse2 = Helper.buildConvAIIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,null);
        ConvAIIntentResponse expectedResponse3 = Helper.buildConvAIIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,null);

        List<ConvAIIntentResponse> expectedResponse = new ArrayList<>();
        expectedResponse.add(expectedResponse1);
        expectedResponse.add(expectedResponse2);
        expectedResponse.add(expectedResponse3);

        Intent mockIntent1 = Helper.buildIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,null);
        Intent mockIntent2 = Helper.buildIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,null);
        Intent mockIntent3 = Helper.buildIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,null);
        List<Intent> mockIntent = new ArrayList<>();
        mockIntent.add(mockIntent1);
        mockIntent.add(mockIntent2);
        mockIntent.add(mockIntent3);

        when(listIntentsPagedResponse.iterateAll()).thenReturn(mockIntent);
        when(intentsClient.listIntents(TEST_TENANT_AGENT_NAME)).thenReturn(listIntentsPagedResponse);

        ResponseEntity<List<ConvAIIntentResponse>> responseObject = intentApi.getAllIntents(TEST_TENANT_ID);
        System.out.println(responseObject);
        assertEquals(ResponseEntity.ok(expectedResponse),responseObject);
    }



    @Test
    public void getIntent_happyCase(){
        ConvAIIntentResponse expectedResponse = Helper.buildConvAIIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,null);
        Intent mockIntent = Helper.buildIntent(TEST_INTENT_NAME,TEST_INTENT_DISPLAY_NAME,TEST_INTENT_PRIORITY,TEST_INTENT_DESCRIPTION,null);
        when(intentsClient.getIntent(TEST_INTENT_NAME)).thenReturn(mockIntent);
        System.out.println(TEST_INTENT_NAME);
        ResponseEntity<ConvAIIntentResponse> responseObject = intentApi.getIntent(TEST_TENANT_ID, TEST_INTENT_DISPLAY_NAME);
        assertEquals(ResponseEntity.ok(expectedResponse), responseObject);
    }




}
