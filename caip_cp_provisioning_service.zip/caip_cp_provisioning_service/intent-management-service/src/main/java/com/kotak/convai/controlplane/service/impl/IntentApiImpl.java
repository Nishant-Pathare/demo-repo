package com.kotak.convai.controlplane.service.impl;

import com.google.cloud.dialogflow.cx.v3.CreateIntentRequest;
import com.google.cloud.dialogflow.cx.v3.Intent;
import com.google.cloud.dialogflow.cx.v3.IntentsClient;
import com.google.cloud.dialogflow.cx.v3.UpdateIntentRequest;
import com.kotak.TenantManagementService;
import com.kotak.convai.controlplane.api.IntentApi;
import com.kotak.convai.controlplane.model.ConvAIAddIntentRequest;
import com.kotak.convai.controlplane.model.ConvAIIntent;
import com.kotak.convai.controlplane.model.ConvAIIntentResponseGetAll;
import com.kotak.convai.controlplane.model.ConvAIUpdateIntentRequest;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;

import static com.kotak.convai.controlplane.service.impl.Helper.*;


@Service
@AllArgsConstructor
public class IntentApiImpl implements IntentApi {


    private TenantManagementService tenantManagementService;

    private IntentsClient intentsClient;

    private static final String INTENT_NAME_IN_PATH_DOES_NOT_MATCH_IN_BODY_UPDATE_INTENT_EXCEPTION_MESSAGE = "Provided intent name in path does not match intent name in request body for updating intent";
    private static final String INTENT_NAME_PROVIDED_IN_BODY_ADD_INTENT_EXCEPTION_MESSAGE = "Intent name should not be provided in request body for creating an intent.";
    private static final String TENANT_ID_PROVIDED_NOT_FOUND_EXCEPTION = "Provided Tenant ID was not found.";
    private static final String INTENT_DISPLAY_NAME_CAN_NOT_BE_EMPTY = "Intent Display name can't be empty.";


    //addIntent
    @Override
    public ResponseEntity<ConvAIIntent> addIntent(String tenantId, ConvAIAddIntentRequest requestObject) {

        if (Objects.nonNull(requestObject.getIntentName()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, INTENT_NAME_PROVIDED_IN_BODY_ADD_INTENT_EXCEPTION_MESSAGE);

        if (requestObject.getIntentDisplayName() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, INTENT_DISPLAY_NAME_CAN_NOT_BE_EMPTY);
        }

        String agentName = tenantManagementService.getAgentIdByTenantId(tenantId)
                .orElseThrow(() -> new NoSuchElementException(TENANT_ID_PROVIDED_NOT_FOUND_EXCEPTION));


        Intent intent = intentsClient.createIntent(CreateIntentRequest.newBuilder()
                .setParent(agentName)
                .setIntent(convAIIntentToIntent(requestObject))
                .build());

        ConvAIIntent responseObject = intentToConvAIIntent(intent);

        return ResponseEntity.ok(responseObject);
    }


    //updateIntent
    @Override
    public ResponseEntity<ConvAIIntent> updateIntent(String tenantId, String intentName, ConvAIUpdateIntentRequest requestObject) {

        if (requestObject.getIntentDisplayName() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, INTENT_DISPLAY_NAME_CAN_NOT_BE_EMPTY);
        }
        String agentName = tenantManagementService.getAgentIdByTenantId(tenantId)
                .orElseThrow(() -> new NoSuchElementException(TENANT_ID_PROVIDED_NOT_FOUND_EXCEPTION));
        if (!Helper.getVendorIntentName(intentName, agentName)
                .equals(requestObject.getIntentName())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, INTENT_NAME_IN_PATH_DOES_NOT_MATCH_IN_BODY_UPDATE_INTENT_EXCEPTION_MESSAGE);
        }
        Intent intent = convAIIntentToIntent(requestObject);


        Intent updatedIntent = intentsClient.updateIntent(UpdateIntentRequest.newBuilder()
                .setIntent(intent)
                .build());

        ConvAIIntent responseObject = intentToConvAIIntent(updatedIntent);

        return ResponseEntity.ok(responseObject);
    }


    //getIntent
    @Override
    public ResponseEntity<ConvAIIntent> getIntent(String tenantId, String intentName) {
        String agentName = tenantManagementService.getAgentIdByTenantId(tenantId)
                .orElseThrow(() -> new NoSuchElementException(TENANT_ID_PROVIDED_NOT_FOUND_EXCEPTION));
        Intent intent = intentsClient.getIntent(getVendorIntentName(intentName, agentName));
        ConvAIIntent responseObject = intentToConvAIIntent(intent);

        return ResponseEntity.ok(responseObject);
    }


    //getAllIntents
    @Override
    public ResponseEntity<List<ConvAIIntentResponseGetAll>> getAllIntents(String tenantId) {
        String agentName = tenantManagementService.getAgentIdByTenantId(tenantId)
                .orElseThrow(() -> new NoSuchElementException(TENANT_ID_PROVIDED_NOT_FOUND_EXCEPTION));

        List<ConvAIIntentResponseGetAll> responseObject = new ArrayList<>();
        for (Intent element : intentsClient.listIntents(agentName).iterateAll()) {

            responseObject.add(intentToConvAIIntentGetAll(element));
        }
        return ResponseEntity.ok(responseObject);
    }


    //deleteIntent
    @Override
    public ResponseEntity<Void> deleteIntent(String intentName, String tenantId) {
        String agentName = tenantManagementService.getAgentIdByTenantId(tenantId)
                .orElseThrow(() -> new NoSuchElementException(TENANT_ID_PROVIDED_NOT_FOUND_EXCEPTION));
        intentsClient.deleteIntent(getVendorIntentName(intentName, agentName));
        return new ResponseEntity<>(HttpStatus.OK);
    }
}