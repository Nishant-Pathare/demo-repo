
package com.kotak.convai.controlplane.service.impl;

import com.google.api.client.util.Lists;
import com.google.cloud.dialogflow.cx.v3.Intent;
import com.kotak.convai.controlplane.model.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class Helper {

    private static final int TEST_INTENT_NUM_TRAINING_PHRASES = 1;
    private static final String TEST_INTENT_TRAINING_PHRASES_PARTS_TEXT1 = "Hello, how are you?";
    private static final String TEST_INTENT_TRAINING_PHRASES_PARTS_TEXT2 = "How can I help you?";
    private static final int TEST_INTENT_TRAINING_PHRASES_REPEAT_COUNT= 1;
    private static final String SLASH_INTENT_SLASH = "/intents/";

    public static String getVendorIntentName(String intentName, String agentName) {
        String vendorIntentName = (new StringBuilder()).append(agentName).append(SLASH_INTENT_SLASH).append(intentName).toString();
        return vendorIntentName;
    }

//***TAKE MUSKAN's HELP HERE FOR TRAINING PHRASES DATA TYPE***
/*

    public static ConvAIIntentResponse intentToConvAIIntent(Intent intent) {
        return buildConvAIIntent(intent.getName()
                , intent.getDisplayName()
                , intent.getPriority()
                , intent.getDescription()
                //, intent.getTrainingPhrasesCount()
                ,*/
/* intent.getTrainingPhrasesList()*//*
null);
    }
*/
    public static List<ConvAIParts> TrainingPhrasesParts1 = Arrays.asList(
            ConvAIParts.builder().text(TEST_INTENT_TRAINING_PHRASES_PARTS_TEXT1).build()
    );
    public static List<ConvAIParts> TrainingPhrasesParts2 = Arrays.asList(
            ConvAIParts.builder().text(TEST_INTENT_TRAINING_PHRASES_PARTS_TEXT1).build()
    );
    public static List<ConvAITrainingPhrases> ConvAITrainingPhrasesList =Arrays.asList(
            ConvAITrainingPhrases.builder().parts(TrainingPhrasesParts1).repeatCount(TEST_INTENT_TRAINING_PHRASES_REPEAT_COUNT).build(),
            ConvAITrainingPhrases.builder().parts(TrainingPhrasesParts2).repeatCount(TEST_INTENT_TRAINING_PHRASES_REPEAT_COUNT).build()

    ) ;

    public static List<Intent.TrainingPhrase> TrainingPhrasesList =Arrays.asList(
            Intent.TrainingPhrase.newBuilder().addParts(Intent.TrainingPhrase.Part.newBuilder().setText(TEST_INTENT_TRAINING_PHRASES_PARTS_TEXT1).build()).setRepeatCount(TEST_INTENT_TRAINING_PHRASES_REPEAT_COUNT).build(),
            Intent.TrainingPhrase.newBuilder().addParts(Intent.TrainingPhrase.Part.newBuilder().setText(TEST_INTENT_TRAINING_PHRASES_PARTS_TEXT2).build()).setRepeatCount(TEST_INTENT_TRAINING_PHRASES_REPEAT_COUNT).build()
    ) ;


    public static Intent convAIIntentToIntent(ConvAIAddIntentRequest convAIIntent) {
        return buildIntent(convAIIntent.getIntentName()
                , convAIIntent.getIntentDisplayName()
                , convAIIntent.getIntentPriority()
                , convAIIntent.getIntentDescription()
                //, convAIIntent.getIntentTrainingPhrases()
                ,null);
    }
    public static Intent convAIIntentToIntent(ConvAIUpdateIntentRequest convAIIntent) {
        return buildIntent(convAIIntent.getIntentName()
                , convAIIntent.getIntentDisplayName()
                , convAIIntent.getIntentPriority()
                , convAIIntent.getIntentDescription()
                //, convAIIntent.getIntentTrainingPhrases()
                , null);
    }


    ///**ADD TRAINING PHRASES**
    public static ConvAIIntentResponse buildConvAIIntent(String intentName, String intentDisplayName, int intentPriority, String intentDescription, List<ConvAITrainingPhrases> intentTrainingPhrases/*,int intentNumTrainingPhrases*/) {
        ConvAIIntentResponse.ConvAIIntentResponseBuilder builder = ConvAIIntentResponse.builder();
        if (Objects.nonNull(intentName)) {
            builder.intentName(intentName);
        }
        //else builder.intentName(" ");

        if (Objects.nonNull(intentDisplayName)) {
            builder.intentDisplayName(intentDisplayName);
        }

        if (Objects.nonNull(intentPriority)) {
            builder.intentPriority(intentPriority);
        }
        if (Objects.nonNull(intentDescription)) {
            builder.intentDescription(intentDescription);
        }

        if (Objects.nonNull(intentTrainingPhrases)) {
            builder.intentTrainingPhrases(intentTrainingPhrases);
        }
        if(Objects.nonNull(intentTrainingPhrases)) {
            builder.intentNumTrainingPhrases(intentTrainingPhrases.size());
        }
        else builder.intentNumTrainingPhrases(0);
        return builder.build();
    }

    public static Intent buildIntent(String intentName,String intentDisplayName, int intentPriority, String intentDescription, List<Intent.TrainingPhrase> intentTrainingPhrases) {
        Intent.Builder builder = Intent.newBuilder();
        if (Objects.nonNull(intentName)) {
            builder.setName(intentName);
        }
        if (Objects.nonNull(intentDisplayName)) {
            builder.setDisplayName(intentDisplayName);
        }

        if (Objects.nonNull(intentPriority)) {
            builder.setPriority(intentPriority);
        }
        if (Objects.nonNull(intentDescription)) {
            builder.setDescription(intentDescription);
        }
        if (Objects.nonNull(intentTrainingPhrases)) {
            builder.addAllTrainingPhrases(intentTrainingPhrases);
        }
        return builder.build();
    }

    public static ConvAIAddIntentRequest buildConvAIAddIntentRequest(String intentName,String intentDisplayName, int intentPriority, String intentDescription, List<ConvAITrainingPhrases> intentTrainingPhrases) {
        ConvAIAddIntentRequest.ConvAIAddIntentRequestBuilder builder = ConvAIAddIntentRequest.builder();
        if (Objects.nonNull(intentName)) {
            builder.intentName(intentName);
        }

        if (Objects.nonNull(intentDisplayName)) {
            builder.intentDisplayName(intentDisplayName);
        }

        if (Objects.nonNull(intentPriority)) {
            builder.intentPriority(intentPriority);
        }
        if (Objects.nonNull(intentDescription)) {
            builder.intentDescription(intentDescription);
        }
        if (Objects.nonNull(intentTrainingPhrases)) {
            builder.intentTrainingPhrases(intentTrainingPhrases);
        }
        return builder.build();
    }

    public static ConvAIUpdateIntentRequest buildConvAIUpdateIntentRequest(String intentName, String intentDisplayName, int intentPriority, String intentDescription, List<ConvAITrainingPhrases> intentTrainingPhrases) {
        ConvAIUpdateIntentRequest.ConvAIUpdateIntentRequestBuilder builder = ConvAIUpdateIntentRequest.builder();
        if (Objects.nonNull(intentName)) {
            builder.intentName(intentName);
        }

        if (Objects.nonNull(intentDisplayName)) {
            builder.intentDisplayName(intentDisplayName);
        }

        if (Objects.nonNull(intentPriority)) {
            builder.intentPriority(intentPriority);
        }
        if (Objects.nonNull(intentDescription)) {
            builder.intentDescription(intentDescription);
        }
        if (Objects.nonNull(intentTrainingPhrases)) {
            builder.intentTrainingPhrases(intentTrainingPhrases);
        }
        return builder.build();
    }

    public static Iterable<? extends Intent.TrainingPhrase> getIntentTrainingPhrases(List<ConvAITrainingPhrases> intentTrainingPhrases) {
        return intentTrainingPhrases != null ? intentTrainingPhrases.stream().map(s -> Intent.TrainingPhrase.newBuilder()
                        .setRepeatCount(s.getRepeatCount() != 0 ? s.getRepeatCount() : 1)
                        .addAllParts(!s.getParts().isEmpty() ? getParts(s.getParts()) : Lists.newArrayList())
                        .build())
                .collect(Collectors.toList()) : Lists.newArrayList();
    }

    public static Iterable<? extends Intent.TrainingPhrase.Part> getParts(List<ConvAIParts> parts) {
        return parts != null ? parts
                .stream().map(s -> Intent.TrainingPhrase.Part.newBuilder()
                        .setText(s.getText())
                        .setParameterId(s.getParameterId() != null ? s.getParameterId() : "")
                        .build()).collect(Collectors.toList()) : Lists.newArrayList();
    }

    //USE LATER FOR PARAMETERS

    //    public static Iterable<? extends Intent.Parameter> getIntentParameters(List<ConvAIParameters> intentParameters) {
//        return intentParameters != null ? intentParameters.stream().map(s -> Intent.Parameter.newBuilder()
//                        .setId(s.getParameterId2())
//                        .setEntityType(s.getEntityType())
//                        .setIsList(s.getIsList())
//                        .setRedact(s.getIsRedacted())
//                        .build())
//                .collect(Collectors.toList()) : Lists.newArrayList();
//    }
}




//    public static Iterable<? extends Intent.TrainingPhrase> getIntentTrainingPhrases(List<ArrayList<String>> partList, int repeatCount){
//        return partList != null? partList.stream().map(s -> Intent.TrainingPhrase.newBuilder()
//                        .setRepeatCount(repeatCount !=0? repeatCount:1)
//                        .addAllParts(!partList.isEmpty() ? getParts(partList) : Lists.newArrayList())
//                        .build())
//                .collect(Collectors.toList()) : Lists.newArrayList();
//    }
//    public static Iterable<? extends Intent.TrainingPhrase.Part> getParts(List<ArrayList<String>> parts){
//        return parts != null? parts
//                .stream().map(s -> Intent.TrainingPhrase.Part.newBuilder()
//                        .setText(s.get(0))
//                        .setParameterId(s.size() != 1 ? s.get(1) : "")
//                        .build()).collect(Collectors.toList()) : Lists.newArrayList();
//    }
//}
