package com.kotak.convai.controlplane.service.impl;

import com.google.api.client.util.Lists;
import com.google.cloud.dialogflow.cx.v3.*;
import com.kotak.TenantManagementService;
import com.kotak.convai.controlplane.api.IntentApi;

import com.kotak.convai.controlplane.model.*;
import com.kotak.convai.controlplane.service.impl.Helper;
import com.kotak.google.dialog.flow.GoogleServiceAccessor;
import lombok.AllArgsConstructor;
import org.checkerframework.checker.units.qual.C;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

import static com.kotak.convai.controlplane.service.impl.Helper.getVendorIntentName;


//Using Mohit's
@Service
@AllArgsConstructor
public class IntentApiImpl implements IntentApi {

    private static final String INTENT_NAME_IN_PATH_DOES_NOT_MATCH_IN_BODY_EXCEPTION_MESSAGE = "Provided intent name  in path does not match name in request body";

    private TenantManagementService tenantManagementService;

    private IntentsClient intentsClient;

    //getIntent
    @Override
    public ResponseEntity<ConvAIIntentResponse> getIntent(String tenantId, String intentDisplayName) {
        String agentName = tenantManagementService.getAgentIdByTenantId(tenantId).get();
        String vendorIntentName = getVendorIntentName(intentDisplayName, agentName);
        Intent intent = intentsClient.getIntent(vendorIntentName);
        return ResponseEntity.ok(new ConvAIIntentResponse(intent.getName(), intent.getDisplayName(), intent.getPriority(),intent.getDescription(), intent.getTrainingPhrasesCount()));
    }

    //getAllIntents
    @Override
    public ResponseEntity<List<ConvAIIntentResponse>> getAllIntents(String tenantId) {

        String agentName = tenantManagementService.getAgentIdByTenantId(tenantId).get();

        List<ConvAIIntentResponse> responseObject = new ArrayList<>();
        for (Intent intent : intentsClient.listIntents(agentName).iterateAll()) {

            responseObject.add(new ConvAIIntentResponse(intent.getName(), intent.getDisplayName(), intent.getPriority(),intent.getDescription(), intent.getTrainingPhrasesCount()));
        }
        return ResponseEntity.ok(responseObject);
    }

    //addIntent
    @Override
    public ResponseEntity<ConvAIIntentResponse> addIntent(String tenantId, ConvAIAddIntentRequest request) {
        String agentName = tenantManagementService.getAgentIdByTenantId(tenantId).get();
        System.out.println("Agent name " + agentName);
        System.out.println("hello yogi" + agentName);
        Intent intent= Intent.newBuilder()
                .setPriority(request.getIntentPriority())
                .setDisplayName(request.getIntentDisplayName())
                .setDescription(request.getIntentDescription())
                .addAllTrainingPhrases(Helper.getIntentTrainingPhrases(request.getIntentTrainingPhrases()))
        //SYNC WITH ENTITY MANAGEMENT SERVICE TO ADD PARAMETERS
              //  .addAllParameters(Helper.getIntentParameters(request.getIntentParameters()))
                .build();
//
//        Intent intent = builder.build();



        CreateIntentRequest createIntentRequest = CreateIntentRequest.newBuilder().setIntent(intent).setParent(agentName).build();

        intent =  intentsClient.createIntent(createIntentRequest);
        System.out.println("Intent" + intent);
        return ResponseEntity.ok(new ConvAIIntentResponse(intent.getName(), intent.getDisplayName(), intent.getPriority(),intent.getDescription(), intent.getTrainingPhrasesCount()));
    }


    //deleteIntent
    @Override
    public ResponseEntity<Void> deleteIntent(String intentDisplayName, String tenantId) {
        String agentName = tenantManagementService.getAgentIdByTenantId(tenantId).get();
        intentsClient.deleteIntent(getVendorIntentName(intentDisplayName,agentName));
        return new ResponseEntity<>(HttpStatus.OK);
    }

    //updateIntent
    @Override
    public ResponseEntity<ConvAIIntentResponse> updateIntent (String tenantId, String intentDisplayName, ConvAIUpdateIntentRequest request) {

        String agentName = tenantManagementService.getAgentIdByTenantId(tenantId).get();
//        if (!Helper.getVendorIntentName(intentDisplayName,agentName).equals(request.getIntentName())){
//            throw new RuntimeException(INTENT_NAME_IN_PATH_DOES_NOT_MATCH_IN_BODY_EXCEPTION_MESSAGE);
//        }
        String vendorIntentName = getVendorIntentName(intentDisplayName, agentName);
        Intent intent = intentsClient.getIntent(vendorIntentName);

        Intent updatedIntent=intent.toBuilder()
                .clearDisplayName()
                .setDisplayName(request.getIntentDisplayName())
                .clearDescription()
                .setDescription(request.getIntentDescription())
                .clearTrainingPhrases()
                .addAllTrainingPhrases(Helper.getIntentTrainingPhrases(request.getIntentTrainingPhrases()))
                .clearPriority()
                .setPriority(request.getIntentPriority())
            //Sync with entity management service for parameters
                //.clearParameters()
                //.addAllParameters(Helper.getIntentParameters(request.getIntentParameters()))
                .build();

         updatedIntent= intentsClient.updateIntent(UpdateIntentRequest.newBuilder()
                .setIntent(updatedIntent).build());

        return ResponseEntity.ok(new ConvAIIntentResponse(updatedIntent.getName(), updatedIntent.getDisplayName(), updatedIntent.getPriority(),updatedIntent.getDescription(), updatedIntent.getTrainingPhrasesCount()));

    }


}

