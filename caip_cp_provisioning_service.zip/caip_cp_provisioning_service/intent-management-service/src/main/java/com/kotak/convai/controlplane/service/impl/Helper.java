
package com.kotak.convai.controlplane.service.impl;

import com.google.cloud.dialogflow.cx.v3.Intent;
import com.kotak.convai.controlplane.model.*;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

import static com.kotak.convai.controlplane.service.impl.SubHelper.*;

public class Helper {


    private static final String SLASH_INTENT_SLASH = "/intents/";

    public static String getVendorIntentName(String intentName, String agentName) {
        return agentName + SLASH_INTENT_SLASH + intentName;
    }

    public static ConvAIIntent intentToConvAIIntent(Intent intent) {
        return buildConvAIIntent(intent.getName()
                , intent.getDisplayName()
                , intent.getPriority()
                , intent.getDescription()
                , TrainingPhrasesToConvAITrainingPhrases(intent.getTrainingPhrasesList())
                , ParameterToConvAIParameter(intent.getParametersList()));
    }

    public static ConvAIIntentResponseGetAll intentToConvAIIntentGetAll(Intent intent) {
        return buildConvAIIntentResponseGetAll(intent.getName()
                , intent.getDisplayName()
                , intent.getPriority()
                , intent.getDescription()
                , intent.getTrainingPhrasesCount());
    }

    public static Intent convAIIntentToIntent(ConvAIAddIntentRequest convAIIntent) {
        return buildIntent(convAIIntent.getIntentName()
                , convAIIntent.getIntentDisplayName()
                , convAIIntent.getIntentPriority()
                , convAIIntent.getIntentDescription()
                , ConvAITrainingPhrasesToTrainingPhrases(convAIIntent.getIntentTrainingPhrases())
                , ConvAIParameterToParameter(convAIIntent.getIntentParameters()));
    }

    public static Intent convAIIntentToIntent(ConvAIUpdateIntentRequest convAIIntent) {
        return buildIntent(convAIIntent.getIntentName()
                , convAIIntent.getIntentDisplayName()
                , convAIIntent.getIntentPriority()
                , convAIIntent.getIntentDescription()
                , ConvAITrainingPhrasesToTrainingPhrases(convAIIntent.getIntentTrainingPhrases())
                , ConvAIParameterToParameter(convAIIntent.getIntentParameters()));
    }


    public static ConvAIIntent buildConvAIIntent(String intentName, String intentDisplayName, int intentPriority, String intentDescription, List<ConvAITrainingPhrases> intentTrainingPhrases, List<ConvAIParameters> intentParameters/*,int intentNumTrainingPhrases*/) {
        ConvAIIntent.ConvAIIntentBuilder builder = ConvAIIntent.builder();

        if (Objects.nonNull(intentName)) {
            builder.intentName(intentName);
        }

        if (Objects.nonNull(intentDisplayName)) {
            builder.intentDisplayName(intentDisplayName);
        }

        builder.intentPriority(Math.max(intentPriority, 0));

        if (Objects.nonNull(intentDescription)) {
            builder.intentDescription(intentDescription);
        }
        else builder.intentDescription("");

        if (Objects.nonNull(intentTrainingPhrases)) {
            builder.intentTrainingPhrases(intentTrainingPhrases);
        }
        else builder.intentTrainingPhrases(Collections.emptyList());

        if (Objects.nonNull(intentParameters)){
            builder.intentParameters(intentParameters);
        }
        else builder.intentParameters(Collections.emptyList());

        if (Objects.nonNull(intentTrainingPhrases)){
            builder.intentNumTrainingPhrases(intentTrainingPhrases.size());
        }
        else builder.intentNumTrainingPhrases(0);
        return builder.build();
    }

    public static ConvAIIntentResponseGetAll buildConvAIIntentResponseGetAll(String intentName, String intentDisplayName, int intentPriority, String intentDescription,int numTrainingPhrases) {
        ConvAIIntentResponseGetAll.ConvAIIntentResponseGetAllBuilder builder = ConvAIIntentResponseGetAll.builder();

        if (Objects.nonNull(intentName)) {
            builder.intentName(intentName);
        }

        if (Objects.nonNull(intentDisplayName)) {
            builder.intentDisplayName(intentDisplayName);
        }
        else builder.intentDisplayName("");

        builder.intentPriority(Math.max(intentPriority, 0));

        if (Objects.nonNull(intentDescription)) {
            builder.intentDescription(intentDescription);
        }
        else builder.intentDescription("");

        builder.intentNumTrainingPhrases(Math.max(numTrainingPhrases, 0));


        return builder.build();
    }

    public static Intent buildIntent(String intentName, String intentDisplayName, int intentPriority, String intentDescription, List<Intent.TrainingPhrase> intentTrainingPhrases, List<Intent.Parameter> intentParameters) {
        Intent.Builder builder = Intent.newBuilder();

        if (Objects.nonNull(intentName)) {
            builder.setName(intentName);
        }

        if (Objects.nonNull(intentDisplayName)) {
            builder.setDisplayName(intentDisplayName);
        }

        builder.setPriority(Math.max(intentPriority, 0));

        if (Objects.nonNull(intentDescription)) {
            builder.setDescription(intentDescription);
        }

        if (Objects.nonNull(intentTrainingPhrases)) {
            builder.addAllTrainingPhrases(intentTrainingPhrases);
        }
        if (Objects.nonNull(intentParameters)){
            builder.addAllParameters(intentParameters);
        }
        return builder.build();
    }

    public static ConvAIAddIntentRequest buildConvAIAddIntentRequest(String intentName, String intentDisplayName, int intentPriority, String intentDescription, List<ConvAITrainingPhrases> intentTrainingPhrases,List<ConvAIParameters> intentParameters) {
        ConvAIAddIntentRequest.ConvAIAddIntentRequestBuilder builder = ConvAIAddIntentRequest.builder();

        if (Objects.nonNull(intentName)) {
            builder.intentName(intentName);
        }

        if (Objects.nonNull(intentDisplayName)) {
            builder.intentDisplayName(intentDisplayName);
        }

        builder.intentPriority(Math.max(intentPriority, 0));

        if (Objects.nonNull(intentDescription)) {
            builder.intentDescription(intentDescription);
        }
        else builder.intentDescription("");

        if (Objects.nonNull(intentTrainingPhrases)) {
            builder.intentTrainingPhrases(intentTrainingPhrases);
        }
        else builder.intentTrainingPhrases(Collections.emptyList());

        if (Objects.nonNull(intentParameters)) {
            builder.intentParameters(intentParameters);
        }
        else builder.intentParameters(Collections.emptyList());

        return builder.build();
    }

    public static ConvAIUpdateIntentRequest buildConvAIUpdateIntentRequest(String intentName, String intentDisplayName, int intentPriority, String intentDescription, List<ConvAITrainingPhrases> intentTrainingPhrases,List<ConvAIParameters> intentParameters) {
        ConvAIUpdateIntentRequest.ConvAIUpdateIntentRequestBuilder builder = ConvAIUpdateIntentRequest.builder();

        if (Objects.nonNull(intentName)) {
            builder.intentName(intentName);
        }

        if (Objects.nonNull(intentDisplayName)) {
            builder.intentDisplayName(intentDisplayName);
        }

        builder.intentPriority(Math.max(intentPriority, 0));

        if (Objects.nonNull(intentDescription)) {
            builder.intentDescription(intentDescription);
        }
        else builder.intentDescription("");

        if (Objects.nonNull(intentTrainingPhrases)) {
            builder.intentTrainingPhrases(intentTrainingPhrases);
        }
        else builder.intentTrainingPhrases(Collections.emptyList());

        if (Objects.nonNull(intentParameters)) {
            builder.intentParameters(intentParameters);
        }
        else builder.intentParameters(Collections.emptyList());

        return builder.build();
    }
}
