package com.kotak.convai.controlplane.service.impl;

import com.google.cloud.dialogflow.cx.v3.Intent;
import com.kotak.convai.controlplane.model.ConvAIParameters;
import com.kotak.convai.controlplane.model.ConvAIParts;
import com.kotak.convai.controlplane.model.ConvAITrainingPhrases;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class SubHelper {


    public static List<ConvAIParameters> ParameterToConvAIParameter(List<Intent.Parameter> parameterList){
        List<ConvAIParameters> result = new ArrayList<>();

        if (Objects.nonNull(parameterList)) {
            for (Intent.Parameter parameter : parameterList) {
                result.add(ConvAIParameters.builder()
                    .parameterId2(parameter.getId())
                    .entityType(parameter.getEntityType())
                    .isList(parameter.getIsList())
                    .isRedacted(parameter.getRedact())
                    .build());
            }
        }
        return result;
    }

    public static List<Intent.Parameter> ConvAIParameterToParameter(List<ConvAIParameters> parameterList){
        List<Intent.Parameter> result = new ArrayList<>();

        if (Objects.nonNull(parameterList)){
            for (ConvAIParameters parameter: parameterList) {
                result.add(Intent.Parameter.newBuilder()
                    .setId(parameter.getParameterId2())
                    .setEntityType(parameter.getEntityType())
                    .setIsList(parameter.getIsList())
                    .setRedact(parameter.getIsRedacted())
                    .build());
            }
        }
        return result;
    }

    public static List<Intent.TrainingPhrase.Part> ConvAIPartsToParts(List<ConvAIParts> partsList){
        List<Intent.TrainingPhrase.Part> result = new ArrayList<>();

        if (Objects.nonNull(partsList)) {
            for (ConvAIParts parts : partsList) {
                result.add(Intent.TrainingPhrase.Part.newBuilder()
                    .setText(parts.getText())
                    .setParameterId(parts.getParameterId())
                    .build());
            }
        }
        return result;
    }

    public static List<ConvAIParts> PartsToConvAIParts(List<Intent.TrainingPhrase.Part> partsList){
        List<ConvAIParts> result = new ArrayList<>();

        if (Objects.nonNull(partsList)) {
            for (Intent.TrainingPhrase.Part parts: partsList) {
                result.add(ConvAIParts.builder()
                    .text(parts.getText())
                    .parameterId(parts.getParameterId())
                    .build());
            }
        }
        return result;
    }

    public static List<ConvAITrainingPhrases> TrainingPhrasesToConvAITrainingPhrases (List<Intent.TrainingPhrase> trainingPhrasesList){
        List<ConvAITrainingPhrases> result = new ArrayList<>();

        if (Objects.nonNull(trainingPhrasesList)){
            for (Intent.TrainingPhrase trainingPhrase: trainingPhrasesList){
                result.add(ConvAITrainingPhrases.builder()
                    .parts(PartsToConvAIParts(trainingPhrase.getPartsList()))
                    .repeatCount(trainingPhrase.getRepeatCount())
                    .build());
            }
        }
        return result;
    }

    public static List<Intent.TrainingPhrase> ConvAITrainingPhrasesToTrainingPhrases (List<ConvAITrainingPhrases> trainingPhrasesList){
        List<Intent.TrainingPhrase> result = new ArrayList<>();

        if (Objects.nonNull(trainingPhrasesList)){
            for (ConvAITrainingPhrases trainingPhrase: trainingPhrasesList){
                result.add(Intent.TrainingPhrase.newBuilder()
                    .addAllParts(ConvAIPartsToParts(trainingPhrase.getParts()))
                    .setRepeatCount(trainingPhrase.getRepeatCount())
                    .build());
            }
        }
        return result;
    }
}
